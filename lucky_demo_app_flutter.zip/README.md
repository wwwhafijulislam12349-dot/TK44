# Lucky Demo App

A Flutter UI prototype inspired by the supplied screenshots.

IMPORTANT:
- This project is a virtual-coin UI demo.
- It does not implement real-money gambling.
- It has no deposit, withdrawal, payment gateway, cash-out, or real-money betting logic.

## Run
1. Install Flutter.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Build Android APK
`flutter build apk --release`

The resulting APK will be under:
`build/app/outputs/flutter-apk/app-release.apk`
