import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final password = TextEditingController();
  bool obscure = true;

  @override
  void dispose() {
    phone.dispose();
    password.dispose();
    super.dispose();
  }

  void login() {
    Navigator.pushReplacementNamed(context, '/home');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF063F3F), Color(0xFF02292F)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Text('LUCKY', style: TextStyle(
                    color: Color(0xFFFFC400), fontSize: 42,
                    fontWeight: FontWeight.w900, letterSpacing: 2)),
                  const Text('DEMO', style: TextStyle(
                    color: Colors.white, fontSize: 20,
                    fontWeight: FontWeight.bold)),
                  const SizedBox(height: 42),
                  const Text('Login',
                    style: TextStyle(color: Color(0xFFFFC400), fontSize: 28,
                    fontWeight: FontWeight.bold)),
                  const SizedBox(height: 24),
                  _field(phone, 'Phone number', Icons.phone),
                  const SizedBox(height: 14),
                  _field(password, 'Password', Icons.lock, obscure: obscure,
                    suffix: IconButton(
                      onPressed: () => setState(() => obscure = !obscure),
                      icon: Icon(obscure ? Icons.visibility_off : Icons.visibility,
                        color: const Color(0xFF25E6C0)),
                    )),
                  const SizedBox(height: 20),
                  Row(children: [
                    Checkbox(value: true, onChanged: (_) {},
                      activeColor: const Color(0xFFFFC400)),
                    const Expanded(child: Text(
                      'Demo mode: virtual coins only',
                      style: TextStyle(color: Colors.white70)))
                  ]),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity, height: 54,
                    child: ElevatedButton(
                      onPressed: login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFC400),
                        foregroundColor: const Color(0xFF663A00),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('LOGIN',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 18),
                  TextButton(
                    onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                    child: const Text('Continue as Demo User',
                      style: TextStyle(color: Color(0xFF25E6C0), fontSize: 16)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String hint, IconData icon,
      {bool obscure = false, Widget? suffix}) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        prefixIcon: Icon(icon, color: const Color(0xFF25E6C0)),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF06363B),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF0A6C73)),
        ),
      ),
    );
  }
}
