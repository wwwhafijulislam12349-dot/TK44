import 'package:flutter/material.dart';
import '../widgets/game_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int nav = 0;
  final games = const [
    ['Super Ace', '🎰'],
    ['Aviator Demo', '✈️'],
    ['Wild Showdown', '🤠'],
    ['Lucky Mischief', '🐯'],
    ['Super Elements', '🧙'],
    ['Magic Wild', '✨'],
    ['Fortune Gems', '💎'],
    ['Circus Joker', '🎪'],
    ['Golden Spin', '👑'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFD90000),
        foregroundColor: Colors.white,
        title: const Text('LUCKY DEMO',
          style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(20)),
            child: const Center(child: Text('🪙 10,000')),
          ),
          const CircleAvatar(
            backgroundColor: Colors.white,
            child: Icon(Icons.person, color: Color(0xFFD90000)),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: nav == 0 ? _home() : _placeholder(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: nav,
        onTap: (i) => setState(() => nav = i),
        selectedItemColor: const Color(0xFFD90000),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: 'Promotion'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Member'),
        ],
      ),
    );
  }

  Widget _home() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 175,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFB30000), Color(0xFFFF5A00)])),
            child: const Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('WELCOME BONUS',
                  style: TextStyle(color: Colors.white, fontSize: 28,
                    fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('10,000 FREE DEMO COINS',
                  style: TextStyle(color: Color(0xFFFFE000), fontSize: 21,
                    fontWeight: FontWeight.bold)),
                SizedBox(height: 12),
                Text('Virtual coins only • No cash value',
                  style: TextStyle(color: Colors.white70)),
              ]),
            ),
          ),
          const SizedBox(height: 10),
          _quickActions(),
          const Padding(
            padding: EdgeInsets.fromLTRB(14, 18, 14, 10),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('Popular Demo Games',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            ),
          ),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(12),
            itemCount: games.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10,
              childAspectRatio: .78),
            itemBuilder: (_, i) => GameCard(
              title: games[i][0], emoji: games[i][1],
              onTap: () => _showGame(games[i][0])),
          ),
        ],
      ),
    );
  }

  Widget _quickActions() {
    final items = [
      [Icons.account_balance_wallet, 'Wallet'],
      [Icons.workspace_premium, 'VIP'],
      [Icons.campaign, 'Offers'],
      [Icons.share, 'Invite'],
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: items.map((e) => Column(children: [
          CircleAvatar(radius: 25, backgroundColor: const Color(0xFFD90000),
            child: Icon(e[0] as IconData, color: Colors.white)),
          const SizedBox(height: 5),
          Text(e[1] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
        ])).toList(),
      ),
    );
  }

  Widget _placeholder() => Center(
    child: Text(
      nav == 1 ? 'Promotion Center (Demo)' : 'Member Center (Demo)',
      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
    ),
  );

  void _showGame(String name) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(name),
        content: const Text(
          'This is a UI demo. The game uses no real money, no deposits, and no cash-out.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
            child: const Text('Close')),
        ],
      ),
    );
  }
}
